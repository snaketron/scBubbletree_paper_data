source("src/Graphics.R")
source("src/Stats.R")
library(Seurat)
library(scBubbletree)
library(ggforce)
dir.create(path = "data/subclusters")


d <- get(load(file = "data/CS_A_processed/d.RData"))
utd <- cbind(d@meta.data, d@reductions$umap@cell.embeddings, d@reductions$tsne@cell.embeddings)
rm(d); gc(); gc()


# H1975
utd$sub_c <- "G3"
utd$sub_c[utd$umap_1 > 10 & utd$umap_2 < -6 & utd$cell_line_demuxlet == "H1975"] <- "G1"
utd$sub_c[utd$umap_1 > 10 & utd$umap_1 < 16 & utd$umap_2 > -6 & utd$cell_line_demuxlet == "H1975"] <- "G2"


g_1 <- (ggplot(data = utd[utd$umap_1 > 10 & utd$umap_2<2.5 & utd$cell_line_demuxlet == "H1975",])+
    geom_point(aes(x = umap_1, y = umap_2, col = sub_c), size = 1)+
    scale_color_manual(values = c("black", "darkgray", "lightgray"))+
    theme(legend.position = "none")+
    xlab(label = "UMAP 1")+
    ylab(label = "UMAP 2")+
    ggtitle(label = "Bubble 4, cell line H1975"))|
  (ggplot(data = utd[utd$umap_1 > 10 & utd$umap_2<2.5 & utd$cell_line_demuxlet == "H1975",])+
     geom_sina(aes(x = " ", y = nCount_RNA, col = sub_c), size = 1)+
     scale_color_manual(values = c("black", "darkgray", "lightgray"))+
     theme(legend.position = "none")+
     xlab(label = "H1975 subclusters")+
     ylab(label = "RNA count")+
     ggtitle(label = ""))


# A549
utd$sub_c <- "G2"
utd$sub_c[utd$umap_1 < 0 & utd$umap_2 < -6.75 & utd$cell_line_demuxlet == "A549"] <- "G1"

g_2 <- (ggplot(data = utd[utd$umap_1 < 0 & utd$umap_2 < -2.5 & utd$cell_line_demuxlet == "A549",])+
    geom_point(aes(x = umap_1, y = umap_2, col = sub_c), size = 1)+
    scale_color_manual(values = c("black", "darkgray", "lightgray"))+
    theme(legend.position = "none")+
    xlab(label = "UMAP 1")+
    ylab(label = "UMAP 2")+
    ggtitle(label = "Bubble 0, cell line A549"))|
  (ggplot(data = utd[utd$umap_1 < 0 & utd$umap_2 < -2.5 & utd$cell_line_demuxlet == "A549",])+
     geom_sina(aes(x = " ", y = nCount_RNA, col = sub_c), size = 1)+
     scale_color_manual(values = c("black", "darkgray", "lightgray"))+
     theme(legend.position = "none")+
     xlab(label = "A549 subclusters")+
     ylab(label = "RNA count")+
     ggtitle(label = ""))



# H838
utd$sub_c <- "G2"
utd$sub_c[utd$umap_1 < -4 & utd$umap_2 < 1.6 & utd$cell_line_demuxlet == "H838"] <- "G1"

g_3 <- (ggplot(data = utd[utd$umap_1 < 0 & utd$umap_2 < 8 & utd$umap_2 > -4 & utd$cell_line_demuxlet == "H838",])+
    geom_point(aes(x = umap_1, y = umap_2, col = sub_c), size = 1)+
    scale_color_manual(values = c("black", "darkgray", "lightgray"))+
    theme(legend.position = "none")+
    xlab(label = "UMAP 1")+
    ylab(label = "UMAP 2")+
    ggtitle(label = "Bubble 1, cell line H838"))|
  (ggplot(data = utd[utd$umap_1 < 0 & utd$umap_2 < 8 & utd$umap_2 > -4 & utd$cell_line_demuxlet == "H838",])+
     geom_sina(aes(x = " ", y = nCount_RNA, col = sub_c), size = 1)+
     scale_color_manual(values = c("black", "darkgray", "lightgray"))+
     theme(legend.position = "none")+
     xlab(label = "H838 subclusters")+
     ylab(label = "RNA count")+
     ggtitle(label = ""))


g <- (g_1/g_2/g_3)+patchwork::plot_annotation(tag_levels = 'A')

ggsave(filename = "data/subclusters/Supplementary_subclusters.pdf",
       plot = g,
       device = "pdf",
       width = 6,
       height = 6.5)




