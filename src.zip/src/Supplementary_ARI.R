source("src/Graphics.R")
source("src/Stats.R")
library(Seurat)
library(scBubbletree)
dir.create(path = "data/ARI")



get_ari_from_matrix <- function(m) {

  aris <- matrix(data = 0, nrow = ncol(m), ncol = ncol(m))
  rownames(aris) <- colnames(m)
  colnames(aris) <- colnames(m)

  for(i in 1:(ncol(m)-1)) {
    for(j in (i+1):ncol(m)) {
      aris[i,j] <- fossil::adj.rand.index(group1 = m[,i],
                                          group2 = m[,j])
      aris[j,i] <- aris[i,j]
    }
  }
  return(aris)
}


get_gini_from_matrix <- function(m, labels) {
  wgi <- numeric(length = ncol(m))
  names(wgi) <- colnames(m)
  for(i in 1:ncol(m)) {
    if(any(is.na(m[,i]))) {
      wgi[i] <- NA
    } else {
      wgi[i] <- scBubbletree::get_gini(labels = labels, clusters = m[,i])$wgi
    }
  }
  return(wgi)
}





##### 1. Dataset A #####
# load Seurat object
d <- get(load(file = "data/CS_A_processed/d.RData"))
louvain_A <- get(load(file = "data/CS_A_processed/k5_louvain.RData"))

# This is the main input of scBubbletree -> matrix A
A <- louvain_A$A
# labels
f <- d$cell_line_demuxlet
rm(d, louvain_A)


medoids_A <- cluster::clara(x = A, k = 5, metric = "euclidean", samples = 100,
                             sampsize = min(nrow(A), (40+2*5)*10))
medoids_A <- get_bubbletree_dummy(x = A, cs = medoids_A$clustering,
                                   B = 100, N_eff = 200, cores = 1)

kmeans_A <- get_bubbletree_kmeans(x = A, k = 5, n_start = 1000, iter_max = 300,
                                  kmeans_algorithm = "MacQueen", cores = 1,
                                  B = 100, N_eff = 200)

louvain_A <- get_bubbletree_graph(x = A, r = 0.003, n_start = 20, iter_max = 100,
                                   algorithm = "original", knn_k = 50, cores = 1,
                                   B = 100, N_eff = 200)

# 'LMR', 'SLM' and 'Leiden'
LMR_A <- get_bubbletree_graph(x = A, r = 0.003, n_start = 20, iter_max = 100,
                              algorithm = "LMR", knn_k = 50, cores = 1,
                              B = 100, N_eff = 200)
SLM_A <- get_bubbletree_graph(x = A, r = 0.003, n_start = 20, iter_max = 100,
                              algorithm = "SLM", knn_k = 50, cores = 1,
                              B = 100, N_eff = 200)
Leiden_A <- get_bubbletree_graph(x = A, r = 0.003, n_start = 20, iter_max = 100,
                                 algorithm = "Leiden", knn_k = 50, cores = 1,
                                 B = 100, N_eff = 200)

clustering_A <- data.frame(kmedoids = as.character(medoids_A$cluster),
                           kmeans = as.character(kmeans_A$cluster),
                           louvain = louvain_A$cluster,
                           LMR = LMR_A$cluster,
                           SLM = SLM_A$cluster,
                           leiden = Leiden_A$cluster)


ARI_A <- get_ari_from_matrix(m = clustering_A)
WGI_A <- get_gini_from_matrix(m = clustering_A, labels = f)
clustering_A <- list(ARI = ARI_A, WGI = WGI_A, clust = clustering_A)
save(clustering_A, file = "data/ARI/clustering_A.RData")





##### 2. Dataset B #####
d <- get(load("data/CS_B_processed/d.RData"))
louvain_B <- get(load(file = "data/CS_B_processed/louvain_pc15_r_0.794.RData"))

A <- louvain_B$A
f1 <- d@meta.data$celltype.l1
f2 <- d@meta.data$celltype.l2
rm(d, louvain_B)
gc();gc();gc();gc();gc();gc();


# will crash (non-RAM related) for such large datasets
# Leiden_B <- get_bubbletree_graph(x = A, r = 0.794, n_start = 20, iter_max = 100,
#                                  algorithm = "Leiden", knn_k = 50, B = 100, N_eff = 200)
Leiden_B <- NA

medoids_B <- cluster::clara(x = A, k = 24, metric = "euclidean",
                            samples = 100, sampsize = min(nrow(A), (40+2*5)*10))
medoids_B <- get_bubbletree_dummy(x = A, cs = medoids_B$clustering,
                                  B = 200, N_eff = 200)

kmeans_B <- get_bubbletree_kmeans(x = A, k = 24, B = 200, N_eff = 200,
                                  kmeans_algorithm = "MacQueen")


louvain_B <- get_bubbletree_graph(x = A, r = 0.794, n_start = 20, iter_max = 100,
                                  algorithm = "original", knn_k = 50, B = 100, N_eff = 200)

LMR_B <- get_bubbletree_graph(x = A, r = 0.794, n_start = 20, iter_max = 100,
                              algorithm = "LMR", knn_k = 50, B = 100, N_eff = 200)

SLM_B <- get_bubbletree_graph(x = A, r = 0.794, n_start = 20, iter_max = 100,
                              algorithm = "SLM", knn_k = 50, B = 100, N_eff = 200)




clustering_B <- data.frame(kmedoids = as.character(medoids_B$cluster),
                           kmeans = as.character(kmeans_B$cluster),
                           louvain = louvain_B$cluster,
                           LMR = LMR_B$cluster,
                           SLM = SLM_B$cluster,
                           leiden = Leiden_B)



ARI_B <- get_ari_from_matrix(m = clustering_B)
WGI_B_f1 <- get_gini_from_matrix(m = clustering_B, labels = f1)
WGI_B_f2 <- get_gini_from_matrix(m = clustering_B, labels = f2)
clustering_B <- list(ARI = ARI_B, WGI_f1 = WGI_B_f1, WGI_f2 = WGI_B_f2, clust = clustering_B)
save(clustering_B, file = "data/ARI/clustering_B.RData")




#### Plots ####
source("src/Graphics.R")
source("src/Stats.R")
library(ggplot2)
library(reshape2)

clustering_A <- get(load(file = "data/ARI/clustering_A.RData"))
clustering_B <- get(load(file = "data/ARI/clustering_B.RData"))


# Dataset A: ARI
x <- clustering_A$ARI
diag(x) <- 1
x <- reshape2::melt(x)
colnames(x) <- c("cluster_i", "cluster_j", "ARI")
x$cluster_i <- as.character(x$cluster_i)
x$cluster_j <- as.character(x$cluster_j)

x$cluster_i[x$cluster_i=="kmeans"] <- "k-means"
x$cluster_j[x$cluster_j=="kmeans"] <- "k-means"
x$cluster_i[x$cluster_i=="kmedoids"] <- "k-medoids"
x$cluster_j[x$cluster_j=="kmedoids"] <- "k-medoids"
x$cluster_i[x$cluster_i=="leiden"] <- "Leiden"
x$cluster_j[x$cluster_j=="leiden"] <- "Leiden"
x$cluster_i[x$cluster_i=="louvain"] <- "Louvain"
x$cluster_j[x$cluster_j=="louvain"] <- "Louvain"

x <- x[x$cluster_i!="k-medoids"&x$cluster_j!="k-medoids",]
x$cluster_i <- factor(x = x$cluster_i, levels = sort(unique(as.character(c(x$cluster_i, x$cluster_j)))))
x$cluster_j <- factor(x = x$cluster_j, levels = sort(unique(as.character(c(x$cluster_i, x$cluster_j)))))


ari_A <- ggplot(data = x)+
  geom_tile(aes(x = cluster_i, y = cluster_j, fill = ARI), col = "white")+
  geom_text(aes(x = cluster_i, y = cluster_j, label = round(x = ARI, digits = 4)),
            col = "black", size = 2.75)+
  scale_fill_gradient(low = "#fefefe", high = "darkgray", limits = c(0.5, 1),
                      breaks = scales::pretty_breaks(n = 3))+
  xlab(label = "Method")+
  ylab(label = "Method")+
  theme_bw(base_size = 10)+
  theme(legend.position = "top")+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  ggtitle(label = "Dataset A (k=5, r=0.003)")+
  guides(fill = guide_colourbar(barwidth = 5, barheight = 0.7))


# Dataset A: WGI
x <- clustering_A$WGI
x <- data.frame(algorithm = names(x), WGI = x)
x$algorithm <- as.character(x$algorithm)
x$algorithm[x$algorithm=="kmeans"] <- "k-means"
x$algorithm[x$algorithm=="kmedoids"] <- "k-medoids"
x$algorithm[x$algorithm=="leiden"] <- "Leiden"
x$algorithm[x$algorithm=="louvain"] <- "Louvain"
x$algorithm <- factor(x = x$algorithm, levels = sort(unique(as.character(x$algorithm))))
x <- x[x$algorithm!="k-medoids",]

wgi_A <- ggplot(data = x)+
  geom_point(aes(x = algorithm, y = WGI))+
  xlab(label = "Method")+
  ylab(label = "WGI")+
  theme_bw(base_size = 10)+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))




# Dataset B: ARI
x <- clustering_B$ARI
diag(x) <- 1
x <- reshape2::melt(x)
colnames(x) <- c("cluster_i", "cluster_j", "ARI")
x$ARI[which(x$cluster_i=="leiden"|x$cluster_j=="leiden")] <- NA

x$cluster_i <- as.character(x$cluster_i)
x$cluster_j <- as.character(x$cluster_j)

x$cluster_i[x$cluster_i=="kmeans"] <- "k-means"
x$cluster_j[x$cluster_j=="kmeans"] <- "k-means"
x$cluster_i[x$cluster_i=="kmedoids"] <- "k-medoids"
x$cluster_j[x$cluster_j=="kmedoids"] <- "k-medoids"
x$cluster_i[x$cluster_i=="leiden"] <- "Leiden"
x$cluster_j[x$cluster_j=="leiden"] <- "Leiden"
x$cluster_i[x$cluster_i=="louvain"] <- "Louvain"
x$cluster_j[x$cluster_j=="louvain"] <- "Louvain"

x <- x[x$cluster_i!="k-medoids"&x$cluster_j!="k-medoids",]
x$cluster_i <- factor(x = x$cluster_i, levels = sort(unique(as.character(c(x$cluster_i, x$cluster_j)))))
x$cluster_j <- factor(x = x$cluster_j, levels = sort(unique(as.character(c(x$cluster_i, x$cluster_j)))))

ari_B <- ggplot(data = x)+
  geom_tile(aes(x = cluster_i, y = cluster_j, fill = ARI), col = "white")+
  geom_text(aes(x = cluster_i, y = cluster_j, label = round(x = ARI, digits = 4)),
            col = "black", size = 2.75)+
  scale_fill_gradient(low = "#fefefe", high = "darkgray",
                      na.value="white", limits = c(0.5, 1),
                      breaks = scales::pretty_breaks(n = 3))+
  xlab(label = "Method")+
  ylab(label = "Method")+
  theme_bw(base_size = 10)+
  theme(legend.position = "top")+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  ggtitle(label = "Dataset B (k=24, r=0.79)")+
  guides(fill = guide_colourbar(barwidth = 5, barheight = 0.7))


# Dataset B: WGI
x <- clustering_B$WGI_f1
x["leiden"] <- NA
x <- data.frame(algorithm = names(x), WGI = x)
x$algorithm <- as.character(x$algorithm)
x$algorithm[x$algorithm=="kmeans"] <- "k-means"
x$algorithm[x$algorithm=="kmedoids"] <- "k-medoids"
x$algorithm[x$algorithm=="leiden"] <- "Leiden"
x$algorithm[x$algorithm=="louvain"] <- "Louvain"
x$algorithm <- factor(x = x$algorithm, levels = sort(unique(as.character(x$algorithm))))
x <- x[x$algorithm!="k-medoids",]

y <- clustering_B$WGI_f2
y["leiden"] <- NA
y <- data.frame(algorithm = names(y), WGI = y)
y$algorithm <- as.character(y$algorithm)
y$algorithm[y$algorithm=="kmeans"] <- "k-means"
y$algorithm[y$algorithm=="kmedoids"] <- "k-medoids"
y$algorithm[y$algorithm=="leiden"] <- "Leiden"
y$algorithm[y$algorithm=="louvain"] <- "Louvain"
y$algorithm <- factor(x = y$algorithm, levels = sort(unique(as.character(y$algorithm))))
y <- y[y$algorithm!="k-medoids",]

wgi_B <- ggplot()+
  geom_point(data = x, aes(x = algorithm, y = WGI), col = "black")+
  geom_point(data = y, aes(x = algorithm, y = WGI), col = "darkgray")+
  xlab(label = "Method")+
  ylab(label = "WGI")+
  theme_bw(base_size = 10)+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))



g <- (((ari_A|wgi_A)+plot_layout(widths = c(2.25, 1)))/
  ((ari_B|wgi_B)+plot_layout(widths = c(2.25, 1))))+
  plot_annotation(tag_levels = 'A')



ggsave(filename = "data/ARI/Supplementary_ARI.pdf",
       plot = g,
       device = "pdf",
       width = 5,
       height = 6)



