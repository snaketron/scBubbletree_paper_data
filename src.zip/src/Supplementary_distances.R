source(file = "src/Graphics.R")
source(file = "src/Stats.R")
library(scBubbletree)
library(Seurat)
library(ggrepel)
require(parallel)
dir.create(path = "data/distances/")

###### 1. Load data ##########
louvain_A <- get(load(file = "data/CS_A_processed/k5_louvain.RData"))
louvain_B <- get(load(file = "data/CS_B_processed/louvain_pc15_r_0.794.RData"))
rm(louvain, k5_louvain)

d_A <- get(load(file = "data/CS_A_processed/d.RData"))
d_B <- get(load(file = "data/CS_B_processed/d.RData"))
rm(d)

A_A <- d_A@reductions$pca@cell.embeddings[, 1:15]
A_B <- d_B@reductions$pca@cell.embeddings[, 1:15]

# meta data
meta <- d_A@meta.data
meta$tSNE_1 <- d_A@reductions$tsne@cell.embeddings[, 1]
meta$tSNE_2 <- d_A@reductions$tsne@cell.embeddings[, 2]
meta$UMAP_1 <- d_A@reductions$umap@cell.embeddings[, 1]
meta$UMAP_2 <- d_A@reductions$umap@cell.embeddings[, 2]
meta$louvain <- louvain_A$cluster
meta_A <- meta


# meta data
meta <- d_B@meta.data
meta$tSNE_1 <- d_B@reductions$tsne@cell.embeddings[, 1]
meta$tSNE_2 <- d_B@reductions$tsne@cell.embeddings[, 2]
meta$UMAP_1 <- d_B@reductions$umap@cell.embeddings[, 1]
meta$UMAP_2 <- d_B@reductions$umap@cell.embeddings[, 2]
meta$louvain <- louvain_B$cluster
meta_B <- meta
rm(meta)



###### 2. UMAP + tSNE from datset A #######

umap_A <- merge(x = aggregate(UMAP_1~louvain, data = meta_A, FUN = median),
                y = aggregate(UMAP_2~louvain, data = meta_A, FUN = median),
                by = "louvain")
tsne_A <- merge(x = aggregate(tSNE_1~louvain, data = meta_A, FUN = median),
                y = aggregate(tSNE_2~louvain, data = meta_A, FUN = median),
                by = "louvain")
umap_tsne_A <- merge(x = umap_A, y = tsne_A, by = "louvain")
rm(umap_A, tsne_A)


g_umap_tsne_A <- (ggplot()+
                    geom_point(data = meta_A, aes(x = UMAP_1, y = UMAP_2, col = as.character(louvain)), size = 0.25)+
                    geom_text_repel(data = umap_tsne_A, aes(x = UMAP_1, y = UMAP_2, label = as.character(louvain)), min.segment.length = 0, size = 3)+
                    theme(legend.position = "none")+
                    xlab(label = "UMAP 1")+
                    ylab(label = "UMAP 2")+
                    scale_color_manual(name = "cluster", values = c("0"="#F8766D", "1"="#A3A500", "2"="#00BF7D", "3"="#00B0F6", "4"="#E76BF3"))+
                    guides(colour = guide_legend(nrow = 2, override.aes = list(size=2)))+
                    scale_radius())|
  (ggplot()+
     geom_point(data = meta_A, aes(x = tSNE_1, y = tSNE_2, col = as.character(louvain)), size = 0.25)+
     geom_text_repel(data = umap_tsne_A, aes(x = tSNE_1, y = tSNE_2, label = as.character(louvain)), min.segment.length = 0, size = 3)+
     theme(legend.position = "none")+
     xlab(label = "tSNE 1")+
     ylab(label = "tSNE 2")+
     scale_color_manual(name = "cluster", values = c("0"="#F8766D", "1"="#A3A500", "2"="#00BF7D", "3"="#00B0F6", "4"="#E76BF3"))+
     guides(colour = guide_legend(nrow = 2, override.aes = list(size=2)))+
     scale_radius())



###### 3. UMAP + tSNE from datset B #######

umap_B <- merge(x = aggregate(UMAP_1~louvain, data = meta_B, FUN = median),
                y = aggregate(UMAP_2~louvain, data = meta_B, FUN = median),
                by = "louvain")
tsne_B <- merge(x = aggregate(tSNE_1~louvain, data = meta_B, FUN = median),
                y = aggregate(tSNE_2~louvain, data = meta_B, FUN = median),
                by = "louvain")
umap_tsne_B <- merge(x = umap_B, y = tsne_B, by = "louvain")
rm(umap_B, tsne_B)


g_umap_tsne_B <-
  (ggplot()+
     geom_point(data = meta_B, aes(x = UMAP_1, y = UMAP_2, col = as.character(louvain)), size = 0.25)+
     geom_text_repel(data = umap_tsne_B, aes(x = UMAP_1, y = UMAP_2, label = as.character(louvain)), min.segment.length = 0, size = 3)+
     theme(legend.position = "none")+
     xlab(label = "UMAP 1")+
     ylab(label = "UMAP 2")+
     scale_color_discrete(name = "cluster")+
     guides(colour = guide_legend(nrow = 2, override.aes = list(size=2)))+
     scale_radius())|
  (ggplot()+
     geom_point(data = meta_B, aes(x = tSNE_1, y = tSNE_2, col = as.character(louvain)), size = 0.25)+
     geom_text_repel(data = umap_tsne_B, aes(x = tSNE_1, y = tSNE_2, label = as.character(louvain)), min.segment.length = 0, size = 3)+
     theme(legend.position = "none")+
     xlab(label = "tSNE 1")+
     ylab(label = "tSNE 2")+
     scale_color_discrete(name = "cluster")+
     guides(colour = guide_legend(nrow = 2, override.aes = list(size=2)))+
     scale_radius())


###### 4. Compute 'celldist' PCA vs. UMAP, PCA vs. tSNE #######


get_hdi_bins <- function(x,
                         y,
                         xs,
                         x_width) {
  stats <- c()
  for(i in 1:length(xs)) {
    j <- which(x >= (xs[i]-x_width) & x < (xs[i]+x_width))
    hdi <- get_hdi(vec = y[j], hdi_level = 0.95)
    row <- data.frame(x = xs[i],
                      y_mean = mean(y[j]),
                      y_L95 = hdi[1],
                      y_H95 = hdi[2])
    stats <- rbind(stats, row)
  }
  return(stats)
}

get_celldist <- function(n_cells,
                         labels,
                         pca,
                         umap = NULL,
                         tsne = NULL,
                         treedist = NULL) {

  get_euc <- function(x, y) {
    return(sqrt(apply(X = (x-y)^2, FUN = sum, MARGIN = 1)))
  }

  is <- sample(x = 1:nrow(pca), size = n_cells, replace = T)
  js <- sample(x = 1:nrow(pca), size = n_cells, replace = T)

  pca_d <- get_euc(x = pca[is,], y = pca[js,])

  umap_d <- NA
  if(is.null(umap)==F) {
    umap_d <- get_euc(x = umap[is,], y = umap[js,])
  }

  tsne_d <- NA
  if(is.null(tsne)==F) {
    tsne_d <- get_euc(x = tsne[is,], y = tsne[js,])
  }

  l <- data.frame(umap_d = umap_d, tsne_d = tsne_d, pca_d = pca_d)

  l$i <- labels[is]
  l$j <- labels[js]
  l$w_vs_b <- ifelse(test = l$i == l$j, yes = "w", no = "b")

  w <- t(apply(X = l[, c("i", "j")], MARGIN = 1, FUN = sort))
  l$i <- w[, 1]
  l$j <- w[, 2]
  l <- merge(x = l, y = treedist_data, by = c("i", "j"))

  return (l)
}



treedist_data <- reshape2::melt(ape::cophenetic.phylo(louvain_A$ph$main_ph))
colnames(treedist_data) <- c("i", "j", "tree_d")
rownames(treedist_data) <- paste0(treedist_data$i, '-', treedist_data$j)

# umap + tsne
celldist_A <- get_celldist(n_cells = 10^6,
                           labels = louvain_A$cluster,
                           pca = louvain_A$A,
                           umap = meta_A[, c("UMAP_1", "UMAP_2")],
                           tsne = meta_A[, c("tSNE_1", "tSNE_2")],
                           treedist = treedist_data)

umap_hdi_A <- get_hdi_bins(x = celldist_A$umap_d,
                         y = celldist_A$pca_d,
                         xs = seq(from = 0, to = 30, by = 2),
                         x_width = 2)
tsne_hdi_A <- get_hdi_bins(x = celldist_A$tsne_d,
                         y = celldist_A$pca_d,
                         xs = seq(from = 0, to = 75, by = 2),
                         x_width = 2)






treedist_data <- reshape2::melt(ape::cophenetic.phylo(louvain_B$ph$main_ph))
colnames(treedist_data) <- c("i", "j", "tree_d")
rownames(treedist_data) <- paste0(treedist_data$i, '-', treedist_data$j)

# umap + tsne
celldist_B <- get_celldist(n_cells = 10^6,
                           labels = louvain_B$cluster,
                           pca = louvain_B$A,
                           umap = meta_B[, c("UMAP_1", "UMAP_2")],
                           tsne = meta_B[, c("tSNE_1", "tSNE_2")],
                           treedist = treedist_data)

hist(celldist_B$umap_d)
hist(celldist_B$tsne_d)
hist(celldist_B$pca_d)


umap_hdi_B <- get_hdi_bins(x = celldist_B$umap_d,
                         y = celldist_B$pca_d,
                         xs = seq(from = 0, to = 25, by = 2),
                         x_width = 2)
tsne_hdi_B <- get_hdi_bins(x = celldist_B$tsne_d,
                         y = celldist_B$pca_d,
                         xs = seq(from = 0, to = 50, by = 2),
                         x_width = 2)


g_celldist <-
  (ggplot()+
     stat_density_2d(data = celldist_A, aes(y = pca_d, x = umap_d, fill = ..density..),
                     geom = "raster", contour = FALSE) +
     scale_fill_distiller(name = "d", palette= "Spectral", direction=-1)+
     geom_errorbar(data = umap_hdi_A, aes(x = x, ymin = y_L95, ymax = y_H95),
                   width = 0, col = "black", size = 0.25)+
     geom_point(data = umap_hdi_A, aes(x = x, y = y_mean), size = 0.25)+
     theme_bw(base_size = 10)+
     theme(legend.position = "none")+
     ylab(label = "15D PCA")+
     xlab(label = "2D UMAP")+
     scale_x_continuous(expand = c(0.005, 0.005), limits = c(-1, 30))+
     scale_y_continuous(expand = c(0, 0), limits = c(0, 150)))|
  (ggplot()+
     stat_density_2d(data = celldist_A, aes(y = pca_d, x = tsne_d, fill = ..density..),
                     geom = "raster", contour = FALSE) +
     scale_fill_distiller(name = "d", palette= "Spectral", direction=-1)+
     geom_errorbar(data = tsne_hdi_A, aes(x = x, ymin = y_L95, ymax = y_H95),
                   width = 0, col = "black", size = 0.25)+
     geom_point(data = tsne_hdi_A, aes(x = x, y = y_mean), size = 0.25)+
     theme_bw(base_size = 10)+
     theme(legend.position = "none")+
     ylab(label = "15D PCA")+
     xlab(label = "2D t-SNE")+
     scale_x_continuous(expand = c(0.005, 0.005), limits = c(-1, 75))+
     scale_y_continuous(expand = c(0, 0), limits = c(0, 150)))|
  (ggplot()+
  stat_density_2d(data = celldist_B, aes(y = pca_d, x = umap_d, fill = ..density..),
                  geom = "raster", contour = FALSE) +
  scale_fill_distiller(name = "d", palette= "Spectral", direction=-1)+
  geom_errorbar(data = umap_hdi_B, aes(x = x, ymin = y_L95, ymax = y_H95),
                width = 0, col = "black", size = 0.25)+
  geom_point(data = umap_hdi_B, aes(x = x, y = y_mean), size = 0.25)+
  theme_bw(base_size = 10)+
  theme(legend.position = "none")+
  ylab(label = "15D PCA")+
  xlab(label = "2D UMAP")+
  scale_x_continuous(expand = c(0.005, 0.005), limits = c(-1, 25))+
  scale_y_continuous(expand = c(0, 0), limits = c(0, 150)))|
  (ggplot()+
     stat_density_2d(data = celldist_B, aes(y = pca_d, x = tsne_d, fill = ..density..),
                     geom = "raster", contour = FALSE) +
     scale_fill_distiller(name = "d", palette= "Spectral", direction=-1)+
     geom_errorbar(data = tsne_hdi_B, aes(x = x, ymin = y_L95, ymax = y_H95),
                   width = 0, col = "black", size = 0.25)+
     geom_point(data = tsne_hdi_B, aes(x = x, y = y_mean), size = 0.25)+
     theme_bw(base_size = 10)+
     theme(legend.position = "none")+
     ylab(label = "15D PCA")+
     xlab(label = "2D t-SNE")+
     scale_x_continuous(expand = c(0.005, 0.005), limits = c(-1, 50))+
     scale_y_continuous(expand = c(0, 0), limits = c(0, 150)))



###### 5. Compute 'bubbledist' PCA vs. UMAP, PCA vs. tSNE #######

get_bubbledist <- function(n_cells_bubble,
                           labels,
                           pca,
                           umap = NULL,
                           tsne = NULL,
                           treedist = NULL) {


  get_euc <- function(x, y) {
    return(sqrt(apply(X = (x-y)^2, FUN = sum, MARGIN = 1)))
  }

  # labels <- k20$cluster
  u_l <- unique(labels)
  len_ul <- length(u_l)
  l <- vector(mode = "list", length = len_ul*(len_ul-1)/2+len_ul)
  u <- 1

  for(i in 1:len_ul) {
    cat(i, "\n")
    is <- which(labels == u_l[i])
    is <- sample(x = is, size = n_cells_bubble, replace = T)
    for(j in i:len_ul) {
      js <- which(labels == u_l[j])
      js <- sample(x = js, size = n_cells_bubble, replace = T)

      pca_d <- get_euc(x = pca[is,], y = pca[js,])

      umap_d <- NA
      if(is.null(umap)==F) {
        umap_d <- get_euc(x = umap[is,], y = umap[js,])
      }

      tsne_d <- NA
      if(is.null(tsne)==F) {
        tsne_d <- get_euc(x = tsne[is,], y = tsne[js,])
      }

      l[[u]] <- data.frame(umap_d = umap_d, tsne_d = tsne_d, pca_d = pca_d)

      l[[u]]$treedist_d = treedist_data$treedist[which(
        treedist_data$i==u_l[i]&treedist_data$j==u_l[j])]
      l[[u]]$i <- u_l[i]
      l[[u]]$j <- u_l[j]
      l[[u]]$w_vs_b <- ifelse(test = i == j, yes = "w", no = "b")
      u<-u+1
    }
  }

  l <- do.call(rbind, l)
  return (l)
}



## data A ##
treedist_data <- reshape2::melt(ape::cophenetic.phylo(louvain_A$ph$main_ph))
colnames(treedist_data) <- c("i", "j", "tree_d")
rownames(treedist_data) <- paste0(treedist_data$i, '-', treedist_data$j)

# bubbletree
bubbledist_A <- get_bubbledist(n_cells_bubble = 10^4,
                               labels = louvain_A$cluster,
                               pca = louvain_A$A,
                               umap = umap_tsne_A[, c("UMAP_1", "UMAP_2")],
                               tsne = umap_tsne_A[, c("tSNE_1", "tSNE_2")],
                               treedist = treedist_data)

b_hdi <- aggregate(pca_d~i+j+w_vs_b, data = bubbledist_A,
                   FUN = get_hdi, hdi_level = 0.95)
b_hdi$pca_L95 <- b_hdi$pca_d[,1]
b_hdi$pca_H95 <- b_hdi$pca_d[,2]
b_hdi$pca_d <- NULL

b_m <- aggregate(pca_d~i+j+w_vs_b, data = bubbledist_A, FUN = mean)
b_m$pca_M <- b_m$pca_d
b_m$pca_d <- NULL

b_stats <- merge(x = b_hdi, y = b_m, by = c("i", "j", "w_vs_b"))
b_stats_A <- merge(x = b_stats, y = treedist_data, by = c("i", "j"))
rm(b_hdi, b_m, b_stats)



## data B ##
treedist_data <- reshape2::melt(ape::cophenetic.phylo(louvain_B$ph$main_ph))
colnames(treedist_data) <- c("i", "j", "tree_d")
rownames(treedist_data) <- paste0(treedist_data$i, '-', treedist_data$j)

# bubbletree
bubbledist_B <- get_bubbledist(n_cells_bubble = 10^4,
                               labels = louvain_B$cluster,
                               pca = louvain_B$A,
                               umap = umap_tsne_B[, c("UMAP_1", "UMAP_2")],
                               tsne = umap_tsne_B[, c("tSNE_1", "tSNE_2")],
                               treedist = treedist_data)

b_hdi <- aggregate(pca_d~i+j+w_vs_b, data = bubbledist_B,
                   FUN = get_hdi, hdi_level = 0.95)
b_hdi$pca_L95 <- b_hdi$pca_d[,1]
b_hdi$pca_H95 <- b_hdi$pca_d[,2]
b_hdi$pca_d <- NULL

b_m <- aggregate(pca_d~i+j+w_vs_b, data = bubbledist_B, FUN = mean)
b_m$pca_M <- b_m$pca_d
b_m$pca_d <- NULL

b_stats <- merge(x = b_hdi, y = b_m, by = c("i", "j", "w_vs_b"))
b_stats_B <- merge(x = b_stats, y = treedist_data, by = c("i", "j"))
rm(b_hdi, b_m, b_stats)




g_btdist <- (ggplot(data = b_stats_A)+
               geom_abline(slope = 1, intercept = 0, linetype = "dashed", col = "darkgray")+
    geom_errorbar(aes(x = tree_d, ymin = pca_L95, ymax = pca_H95, y = pca_M),
                  width = 0, size = 0.35, col = "darkgray",
                  position = position_jitter(width = 0.5, height = 0, seed = 1234))+
    geom_point(aes(x = tree_d, y = pca_M), size = 0.7,
               position = position_jitter(width = 0.5, height = 0, seed = 1234))+
    xlab(label = "Bubbletree distance")+
    ylab(label = "15D PCA")+
    theme(legend.position = "top"))|
  (ggplot(data = b_stats_B)+
     geom_abline(slope = 1, intercept = 0, linetype = "dashed", col = "darkgray")+
     geom_errorbar(aes(x = tree_d, ymin = pca_L95, ymax = pca_H95, y = pca_M),
                   width = 0, size = 0.35, col = "darkgray",
                   position = position_jitter(width = 0.5, height = 0, seed = 1234))+
     geom_point(aes(x = tree_d, y = pca_M), size = 0.7,
                position = position_jitter(width = 0.5, height = 0, seed = 1234))+
     xlab(label = "Bubbletree distance")+
     ylab(label = "15D PCA")+
     theme(legend.position = "top"))




g <- (g_umap_tsne_A/g_umap_tsne_B/g_celldist/g_btdist)+
  patchwork::plot_layout(heights = c(1, 1, 0.5, 0.5))+
  patchwork::plot_annotation(tag_levels = 'A')


ggsave(plot = g,
       filename = "data/distances/Supplementary_distances.png",
       device = "png",
       dpi = 300,
       width = 6.5,
       height = 8)
