##### 1: generating Seurat object #####
source("src/Graphics.R")
source("src/Stats.R")
library(Seurat)

# load data
load("data/CS_A_raw/sincell_with_class_5cl.RData")

# we are only interested in the 10x data object 'sce_sc_10x_5cl_qc'
d <- sce_sc_10x_5cl_qc

# remove the remaining objects (cleanup)
rm(sc_Celseq2_5cl_p1, sc_Celseq2_5cl_p2, sc_Celseq2_5cl_p3, sce_sc_10x_5cl_qc)

# get the meta data for each cell
meta <- colData(d)[, c("cell_line_demuxlet", "non_mt_percent", "total_features")]

# create Seurat object from the raw counts and append the meta data to it
d <- Seurat::CreateSeuratObject(counts = d@assays$data$counts, project = 'cancer_cells')

# check if all cells are matched between d and meta
# table(rownames(d@meta.data) == meta@rownames)
d@meta.data <- cbind(d@meta.data, meta@listData)

# cell type predictions are provided as part of the meta data
table(d@meta.data$cell_line)

# select 5,000 most variable genes
d <- Seurat::FindVariableFeatures(object = d, selection.method = "vst", nfeatures = 5000)

# Preprocessing with Seurat: SCT transformation + PCA + UMAP
d <- SCTransform(object = d, variable.features.n = 5000)

# Run PCA
d <- RunPCA(object = d, npcs = 50, features = VariableFeatures(object = d))

# Run UMAP and tSNE based on top-15 PCs
d <- RunUMAP(d, dims = 1:15)
d <- RunTSNE(d, dims = 1:15)

# Save file to new folder
dir.create("data/CS_A_processed/")
save(d, file = "data/CS_A_processed/d.RData")



##### 2: scBubbletree analysis #####
source("src/Graphics.R")
source("src/Stats.R")
library(Seurat)
library(scBubbletree)

# load Seurat object 'd'
d <- get(load("data/CS_A_processed/d.RData"))

# matrix A: the main input of scBubbletree
A <- d@reductions$pca@cell.embeddings[, 1:15]

data_k <- get_k(B_gap = 50, # bootstraps for Gap stat computation
                ks = 1:20, # resolutions
                x = A,
                n_start = 20, # number of random starts for clustering alg
                iter_max = 100, # number of random iterations for clustering alg
                kmeans_algorithm = "MacQueen", # algorithm
                cores = 50) # number of PC cores to use
save(data_k, file = "data/CS_A_processed/data_k.RData")

data_r <- get_r(B_gap = 50, # bootstraps for Gap stat computation
                rs = 10^seq(from = -4, to = 1, by = 0.1), # resolutions
                x = A,
                n_start = 20, # number of random starts for clustering alg
                iter_max = 100, # number of random iterations for clustering alg
                knn_k = 50, # number of neighbors in k-nearest network graph
                algorithm = "original", # algorithm
                cores = 20) # number of PC cores to use
save(data_r, file = "data/CS_A_processed/data_r.RData")





# graph-based clustering
k5_louvain <- get_bubbletree_graph(x = A,
                                   r = 0.003,
                                   n_start = 20,
                                   iter_max = 100,
                                   algorithm = "original",
                                   knn_k = 50,
                                   cores = 20,
                                   B = 1000,
                                   N_eff = 200,
                                   round_digits = 1,
                                   show_simple_count = F)
save(k5_louvain, file = "data/CS_A_processed/k5_louvain.RData")




# kmeans-based clustering
k5_kmeans <- get_bubbletree_kmeans(x = A,
                                   k = 5,
                                   n_start = 1000,
                                   iter_max = 300,
                                   kmeans_algorithm = "MacQueen",
                                   hclust_distance = "euclidean",
                                   hclust_method = "average",
                                   cores = 20,
                                   B = 1000,
                                   N_eff = 200,
                                   round_digits = 1,
                                   show_simple_count = F)
save(k5_kmeans, file = "data/CS_A_processed/k5_kmeans.RData")




##### 3: Inspect Neff #####
source("src/Graphics.R")
k5_louvain <- get(load("data/CS_A_processed/k5_louvain.RData"))

A <- k5_louvain$A
cs <- k5_louvain$cluster


inspect_neff <- function(A, cs, bs, neffs, cores) {

  get_dist <- function(B, m, c, N_eff, cores, hclust_distance) {

    # Short description:
    # For b in 1:B computes pairwise inter-cluster distances using
    # bootstrapping
    get_p_dist <- function(x, m, c, N_eff, hclust_distance) {

      cs <- unique(c)
      stats <- c()
      len_cs <- length(cs)
      with_replacement <- TRUE

      stats <- vector(mode = "list", length = len_cs*len_cs)
      counter <- 1
      for(i in seq_len(length.out = len_cs)) {
        x_i <- m[which(c == cs[i]), ]
        if(is.vector(x_i)) {
          x_i <- matrix(data = x_i, nrow = 1)
        }

        if(is.na(N_eff)==FALSE) {
          # efficiency
          if(nrow(x_i)>N_eff) {
            x_i <- x_i[sample(x = seq_len(length.out=nrow(x_i)),
                              size = N_eff,
                              replace = with_replacement), ]
          }
        }

        for(j in i:len_cs) {
          x_j <- m[which(c == cs[j]), ]
          if(is.vector(x_j)) {
            x_j <- matrix(data = x_j, nrow = 1)
          }

          if(is.na(N_eff)==FALSE) {
            # efficiency
            if(nrow(x_j)>N_eff) {
              x_j <- x_j[sample(x = seq_len(length.out=nrow(x_j)),
                                size = N_eff,
                                replace = with_replacement), ]
            }
          }

          # Euclidean distance
          if(hclust_distance=="euclidean") {
            w <- proxy::dist(x = x_i, y = x_j, method = "Euclidean")
          }
          # Manhattan distance
          if(hclust_distance=="manhattan") {
            w <- proxy::dist(x = x_i, y = x_j, method = "Manhattan")
          }

          # symmetric distances
          stats[[counter]]<-data.frame(c_i = cs[i], c_j = cs[j], B = x, M = mean(w),
                                       n_i = nrow(x_i), n_j = nrow(x_j))
          counter <- counter + 1
          if(i!=j) {
            stats[[counter]]<-data.frame(c_i = cs[j], c_j = cs[i], B = x, M = mean(w),
                                         n_i = nrow(x_j), n_j = nrow(x_i))
            counter <- counter + 1
          }
        }
      }

      stats <- do.call(rbind, stats)
      return(stats)
    }


    # Short description:
    # Compute distance between centroids
    get_c_dist <- function(m, c, hclust_distance) {
      cs <- unique(c)
      stats <- c()
      len_cs <- length(cs)

      stats <- vector(mode = "list", length = len_cs*len_cs)
      counter <- 1
      for(i in seq_len(length.out = len_cs)) {
        x_i <- m[which(c == cs[i]), ]
        x_i <- colMeans(x_i)

        for(j in i:len_cs) {
          x_j <- m[which(c == cs[j]), ]
          x_j <- colMeans(x_j)

          # Euclidean distance
          if(hclust_distance=="euclidean") {
            M <- sqrt(sum((x_i-x_j)^2))
          }
          # Manhattan distance
          if(hclust_distance=="manhattan") {
            M <- sum(abs((x_i-x_j)))
          }

          # symmetric distances
          stats[[counter]] <- data.frame(c_i = cs[i], c_j = cs[j], B = 1, M = M)
          counter <- counter + 1
          if(i!=j) {
            stats[[counter]] <- data.frame(c_i = cs[j], c_j = cs[i], B = 1, M = M)
            counter <- counter + 1
          }
        }
      }

      stats <- do.call(rbind, stats)
      return(stats)
    }


    # Short description:
    # computes summaries (mean + SE) of  inter-cluster PCA distance
    get_p_dist_summary <- function(p_dist) {
      B <- max(p_dist$B)

      m <- merge(x = aggregate(M~c_i+c_j, data = p_dist, FUN = mean),
                 y = aggregate(M~c_i+c_j, data = p_dist, FUN = get_se),
                 by = c("c_i", "c_j"))
      colnames(m) <- c("c_i", "c_j", "M", "SE")
      m$L95 <- m$M-m$SE*1.96
      m$H95 <- m$M+m$SE*1.96

      return(m)
    }


    # Short description:
    # aux. function which computes standard error of num. vector x
    get_se <- function(x) {
      if(missing(x)|length(x)==0) {
        stop("x is missing or length(x)==0")
      }
      if(length(x) == 1) {
        se <- NA
      }
      else {
        se <- sd(x)/sqrt(length(x))
      }
      return(se)
    }


    # get centroid distances
    c_dist <- get_c_dist(m = m, c = c, hclust_distance = hclust_distance)
    p_dist <- NA
    p_dist_summary <- NA

    if(B>0) {
      # get distances between clusters in B bootstrap iterations
      future::plan(future::multisession, workers = cores)
      p_dist <- future.apply::future_lapply(X = seq_len(length.out = B),
                                            FUN = get_p_dist,
                                            m = m,
                                            c = c,
                                            N_eff = N_eff,
                                            hclust_distance = hclust_distance,
                                            future.seed = TRUE)
      future::plan(future::sequential())

      # collect results
      p_dist <- do.call(rbind, p_dist)

      # get additional summaries
      p_dist_summary <- get_p_dist_summary(p_dist = p_dist)
    }

    return(list(c_dist = c_dist,
                p_dist = p_dist,
                p_dist_summary = p_dist_summary))
  }

  get_exact_dist <- function(A, cs) {
    unique_cs <- unique(cs)

    w <- matrix(data = 0, nrow = length(unique_cs), ncol = length(unique_cs))
    colnames(w) <- unique_cs
    rownames(w) <- unique_cs

    for(i in 1:(length(unique_cs)-1)) {
      for(j in (i+1):length(unique_cs)) {
        A_x <- A[which(cs==unique_cs[i]),]
        A_y <- A[which(cs==unique_cs[j]),]

        w[i,j] <- mean(proxy::dist(x = A_x, y = A_y, method = "Euclidean"))
        w[j,i] <- w[i,j]
      }
    }

    w <- reshape2::melt(w)
    colnames(w) <- c("c_i", "c_j", "E")
    w$n_i <- NA
    w$n_j <- NA

    for(i in 1:nrow(w)) {
      w$n_i[i] <- sum(cs == w$c_i[i])
      w$n_j[i] <- sum(cs == w$c_j[i])
    }

    return(w)
  }

  get_delta <- function(e, p, neff, b) {
    w <- merge(x = e, y = p, by = c("c_i", "c_j"))
    w$diff <- w$E-w$M
    w <- w[w$c_i != w$c_j,]
    w$neff <- neff
    w$B <- b

    return(w)
  }

  # compute explicit distances between clusters -> E
  e <- get_exact_dist(A=A, cs=cs)

  neff_res <- vector(mode = "list",
                     length = length(bs)*length(neffs))
  counter <- 1
  for(neff in neffs) {
    for(b in bs) {
      cat("N_eff=", neff, " B=", b, "\n")

      # compute approximate distances as done by scBubbletree -> M
      pd <- get_dist(B = b,
                     m = A,
                     c = cs,
                     N_eff = neff,
                     cores = cores,
                     hclust_distance = "euclidean")

      # compare E and M
      neff_res[[counter]] <- get_delta(e = e,
                                       p = pd$p_dist_summary,
                                       neff = neff,
                                       b = b)
      counter <- counter + 1
    }
  }
  return(do.call(rbind, neff_res))
}


neff <- inspect_neff(A = A,
                     cs = cs,
                     bs = c(25, 50, 100, 200, 400),
                     neffs = c(25, 50, 100, 200, 400),
                     cores = 20)

save(neff, file = "data/CS_A_processed/neff.RData")



neff <- get(load("data/CS_A_processed/neff.RData"))
neff$B_lab <- paste0("B=",neff$B)
neff$B_lab <- factor(x = neff$B_lab, levels = unique(neff$B_lab))
neff$neff_lab <- paste0("Neff=",neff$neff)
neff$neff_lab <- factor(x = neff$neff_lab, levels = unique(neff$neff_lab))

g <- ggplot(data = neff)+
  facet_grid(neff_lab~B_lab)+
  geom_point(aes(y = M, x = E), size = 0.5)+
  geom_errorbar(aes(y = M, x = E, ymin = L95, ymax = H95), width = 0.1)+
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", col = "gray")+
  ggtitle(label = "Data set A")

ggsave(filename = "data/CS_A_processed/neff.pdf",
       plot = g,
       device = "pdf",
       width = 6,
       height = 6)




##### 4: too-many-cells ########
source("src/Graphics.R")
library(dendextend)
library(data.tree)
library(jsonlite)
k5_louvain <- get(load("data/CS_A_processed/k5_louvain.RData"))

A <- k5_louvain$A
cs <- k5_louvain$cluster
hc <- k5_louvain$pair_dist$p_dist_summary
hc <- reshape2::acast(formula = c_i~c_j, data = hc, value.var = "M")
# Get hclust tree.
hc = hclust(dist(hc), "ave")

# Get dendrogram.
dend = as.dendrogram(hc)
# Get nicely formatted tree from dendrogram.
tree = as.Node(dend)
# Convert to JSON
json = toJSON(as.list(tree, mode = "explicit", unname = TRUE))
# Write to file
cat(json, file = "data/CS_B_processed/tmc_tree.json")



##### 5: Fig 1 ######
source("src/Graphics.R")
library(scBubbletree)
library(patchwork)

d <- get(load("data/CS_A_processed/d.RData"))
k5_louvain <- get(load("data/CS_A_processed/k5_louvain.RData"))
data_r <- get(load("data/CS_A_processed/data_r.RData"))

gini_r <- get_gini_k(labels = d$cell_line_demuxlet, obj = data_r)


as <- t(as.matrix(d@assays$SCT@data[rownames(d@assays$SCT@data) %in%
                                      c("ALDH1A1", "PIP4K2C",
                                        "S100A9", "SLPI", "CT45A2"), ]))
as <- as[, c("ALDH1A1", "PIP4K2C", "S100A9", "SLPI", "CT45A2")]


g_gap <- ggplot(data_r$gap_stats_summary)+
  geom_line(aes(y = gap_mean, x = k), col = "darkgray")+
  geom_point(aes(y = gap_mean, x = k), size = 0.5, col = "black")+
  geom_errorbar(aes(y = gap_mean, x = k, ymin = L95, ymax = H95), width = 0.1)+
  xlab(label = "k'")+
  ylab(label = "Gap")

g_wgi <- ggplot()+
  geom_line(data = gini_r$wgi, aes(x = k, y = wgi), size = 0.2)+
  geom_point(data = gini_r$wgi, aes(x = k, y = wgi),
             size = 0.5, col = "black")+
  ylab(label = "WGI")+
  xlab(label = "k'")


w_cell_line <- get_cat_tiles(btd = k5_louvain,
                             f = d@meta.data$cell_line_demuxlet,
                             integrate_vertical = F,
                             round_digits = 1,
                             tile_bw = F,
                             x_axis_name = 'Cell line',
                             rotate_x_axis_labels = T,
                             tile_text_size = 2.75)

w_exp <- get_num_tiles(btd = k5_louvain,
                       fs = as,
                       summary_function = "mean",
                       round_digits = 1,
                       tile_text_size = 2.75,
                       tile_bw = F,
                       x_axis_name = "Marker gene",
                       rotate_x_axis = T)

w_violin <- get_num_violins(btd = k5_louvain,
                            fs = as,
                            x_axis_name = "Gene expression",
                            rotate_x_axis_labels = F)


g_up <- (g_gap|g_gap|g_wgi)+plot_layout(widths = c(2, 1, 1))

g_bottom <- (k5_louvain$tree|w_cell_line$plot|w_exp$plot|w_violin$plot)+
  plot_layout(widths = c(0.3, 0.3, 0.3, 0.5))

g <- g_up/g_bottom+plot_layout(heights = c(1.2, 3))

g <- g + plot_annotation(tag_levels = 'A')

ggsave(plot = g,
       filename = "data/CS_A_processed/fig_1.pdf",
       device = "pdf",
       width = 9,
       height = 4.5)




##### 6. Supplementary dataset A ######
source("src/Graphics.R")
library(scBubbletree)
library(patchwork)

d <- get(load("data/CS_A_processed/d.RData"))
k5_louvain <- get(load("data/CS_A_processed/k5_louvain.RData"))
k5_kmeans <- get(load("data/CS_A_processed/k5_kmeans.RData"))


# w_comp <- scBubbletree::compare_bubbletrees(btd_1 = k5_louvain, btd_2 = k5_kmeans)

w_cell_line <- get_cat_tiles(btd = k5_louvain,
                             f = d@meta.data$cell_line_demuxlet,
                             integrate_vertical = F,
                             round_digits = 1,
                             tile_bw = T,
                             x_axis_name = 'Cell line',
                             rotate_x_axis_labels = T,
                             tile_text_size = 2.75)


w_mt_dist <- get_num_violins(btd = k5_louvain,
                             fs = 1-d@meta.data$non_mt_percent,
                             x_axis_name = 'MT [%]',
                             rotate_x_axis_labels = T)

w_umi_dist <- get_num_violins(btd = k5_louvain,
                              fs = d@meta.data$nCount_RNA/1000,
                              x_axis_name = 'RNA count (in thousands)',
                              rotate_x_axis_labels = T)

w_gene_dist <- get_num_violins(btd = k5_louvain,
                               fs = d@meta.data$nFeature_RNA,
                               x_axis_name = 'Gene count',
                               rotate_x_axis_labels = T)


g <- (k5_louvain$tree|w_cell_line$plot|w_mt_dist$plot|w_umi_dist$plot|w_gene_dist$plot)+
  plot_layout(widths = c(0.7, 1, 0.5, 0.5, 0.5))+
  plot_annotation(tag_levels = 'A')


ggsave(plot = g,
       filename = "data/CS_A_processed/Supplementary_A.pdf",
       device = "pdf",
       width = 10,
       height = 3.5)



##### 7. Supplementary dataset r vs. k ######
source("src/Graphics.R")
library(scBubbletree)
library(patchwork)

r_a <- get(load("data/CS_A_processed/data_r.RData"))
r_b <- get(load("data/CS_B_processed/data_r_pc15.RData"))

g_a <- (ggplot(data = r_a$gap_stats_summary)+
        geom_point(aes(x = r, y = k), size = 0.5)+
        scale_x_log10()+
        ylab(label = 'k\'')+
        annotation_logticks(base = 10, sides = "b")+
        ggtitle(label = "Dataset A"))
g_b <- (ggplot(data = r_b$gap_stats_summary)+
          geom_point(aes(x = r, y = k), size = 0.5)+
          scale_x_log10()+
          ylab(label = 'k\'')+
          annotation_logticks(base = 10, sides = "b")+
          ggtitle(label = "Dataset B"))

g <- (g_a|g_b)+plot_annotation(tag_levels = 'A')

ggsave(plot = g,
       filename = "data/CS_A_processed/Supplementary_k_vs_r.pdf",
       device = "pdf",
       width = 6,
       height = 3)





