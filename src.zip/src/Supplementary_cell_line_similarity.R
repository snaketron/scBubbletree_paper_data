source("src/Graphics.R")
source("src/Stats.R")
library(ggplot2)
library(ggrepel)


get_sort_paste <- function(x) {
  return(paste0(sort(x), collapse = ' vs. '))
}


tpm <- read.csv(file = "data/cell_line_similarity/E-MTAB-2770-query-results.tpms.tsv",
                sep = "\t", comment.char = "#")


tpm <- tpm[, c(1, 2, which(regexpr(pattern = "lung\\.adenocarcinoma",
                                   text = colnames(tpm)) != -1))]
rownames(tpm) <- tpm$Gene.ID
tpm$Gene.ID <- NULL
tpm$Gene.Name <- NULL
tpm <- t(tpm)
rownames(tpm) <- gsub(pattern = "\\.\\.papillary\\.lung\\.adenocarcinoma|\\..lung\\.adenocarcinoma|NCI\\.",
                      replacement = '', x = rownames(tpm))
rownames(tpm) <- gsub(pattern = "\\.",
                      replacement = '',
                      x = rownames(tpm))



w <- as.matrix(dist(tpm, method = "euclidean"))
w <- reshape2::melt(w)
colnames(w) <- c("c1", "c2", "d")
w$pair <- apply(X = w[, c("c1", "c2")], MARGIN = 1, FUN = get_sort_paste)
w <- w[w$c1 != w$c2, ]
w <- w[duplicated(w$pair)==F, ]
w <- w[order(w$d, decreasing = F), ]
w$rank <- 1:nrow(w)

q <- w[w$c1 %in% c("H838", "H2228", "A549", "H1975", "HCC827") &
         w$c2 %in% c("H838", "H2228", "A549", "H1975", "HCC827"), ]


gdist <- ggplot()+
  geom_histogram(data = w, aes(d), bins = 50, fill = "gray", col = "gray")+
  geom_point(data = q, aes(x = d, y = 0), shape = 21, col = "red", size = 2,
             position = position_jitter(width = 0, height = 2))+
  geom_text_repel(data = q[q$pair == "H1975 vs. HCC827", ],
                  aes(x = d, y = 0, label = pair), col = "red", size = 3,
                  min.segment.length = 0, max.overlaps = 100, nudge_y = 5,
                  force = 2, max.iter = 10^6)+
  theme_bw()+
  scale_x_log10()+
  annotation_logticks(base = 10, sides = "b")+
  xlab(label = "Euclidean distance")+
  ylab(label = "Frequency")

gdist
