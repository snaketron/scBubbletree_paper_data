##### 1: generating Seurat object #####
source("src/Graphics.R")
source("src/Stats.R")
library(Seurat)
library(SeuratDisk)

# download reference data from vignette:
# https://atlas.fredhutch.org/data/nygc/multimodal/pbmc_multimodal.h5seurat

# load SeuratDisk
d <- LoadH5Seurat("data/CS_B_raw/pbmc_multimodal.h5seurat")

# remove precomputed reductions
d[["mt"]] <- PercentageFeatureSet(d, pattern = "^MT-")
d@reductions$apca <- NULL
d@reductions$aumap <- NULL
d@reductions$spca <- NULL
d@reductions$wnn.umap <- NULL
d@reductions$umap <- NULL

# run UMAP and t-SNE again
d <- RunUMAP(object = d, dims = 1:15, reduction = "pca")
d <- RunTSNE(object = d, dims = 1:15, reduction = "pca")

# Save file to new folder
dir.create("data/CS_B_processed/")
save(d, file = "data/CS_B_processed/d.RData")



##### 2: scBubbletree analysis #####
source("src/Graphics.R")
source("src/Stats.R")
library(Seurat)
library(scBubbletree)



# load Seurat object 'd'
d <- get(load("data/CS_B_processed/d.RData"))

# matrix A: the main input of scBubbletree
A <- d@reductions$pca@cell.embeddings[, 1:15]
rm(d);gc();gc()

data_r <- get_r(B_gap = 50, # bootstraps for Gap stat computation
                rs = 10^seq(from = -4, to = 1, by = 0.1), # resolutions
                x = A,
                n_start = 20, # number of random starts for clustering alg
                iter_max = 100, # number of random iterations for clustering alg
                knn_k = 50, # number of neighbors in k-nearest network graph
                algorithm = "original", # algorithm
                cores = 70) # number of PC cores to use

save(data_r, file = "data/CS_B_processed/data_r_pc15_v2.RData")





d <- get(load("data/CS_B_processed/d.RData"))

# matrix A: the main input of scBubbletree
A <- d@reductions$pca@cell.embeddings[, 1:15]
rm(d);gc();gc()

louvain <- get_bubbletree_graph(x = A,
                                r = 10^seq(from = -4, to = 1, by = 0.1)[40],
                                n_start = 20,
                                iter_max = 100,
                                algorithm = "original",
                                knn_k = 50,
                                cores = 70,
                                B = 1000,
                                N_eff = 200,
                                round_digits = 1,
                                show_simple_count = T)
save(louvain, file = "data/CS_B_processed/louvain_pc15_r_0.794.RData")




##### 3: Inspect Neff #####
source("src/Graphics.R")
btd <- get(load("data/CS_B_processed/louvain_pc15_r_0.794.RData"))
rm(louvain); gc(); gc();

A <- btd$A
cs <- btd$cluster


inspect_neff <- function(A, cs, bs, neffs, cores) {

  get_dist <- function(B, m, c, N_eff, cores, hclust_distance) {

    # Short description:
    # For b in 1:B computes pairwise inter-cluster distances using
    # bootstrapping
    get_p_dist <- function(x, m, c, N_eff, hclust_distance) {

      cs <- unique(c)
      stats <- c()
      len_cs <- length(cs)
      with_replacement <- TRUE

      stats <- vector(mode = "list", length = len_cs*len_cs)
      counter <- 1
      for(i in seq_len(length.out = len_cs)) {
        x_i <- m[which(c == cs[i]), ]
        if(is.vector(x_i)) {
          x_i <- matrix(data = x_i, nrow = 1)
        }

        if(is.na(N_eff)==FALSE) {
          # efficiency
          if(nrow(x_i)>N_eff) {
            x_i <- x_i[sample(x = seq_len(length.out=nrow(x_i)),
                              size = N_eff,
                              replace = with_replacement), ]
          }
        }

        for(j in i:len_cs) {
          x_j <- m[which(c == cs[j]), ]
          if(is.vector(x_j)) {
            x_j <- matrix(data = x_j, nrow = 1)
          }

          if(is.na(N_eff)==FALSE) {
            # efficiency
            if(nrow(x_j)>N_eff) {
              x_j <- x_j[sample(x = seq_len(length.out=nrow(x_j)),
                                size = N_eff,
                                replace = with_replacement), ]
            }
          }

          # Euclidean distance
          if(hclust_distance=="euclidean") {
            w <- proxy::dist(x = x_i, y = x_j, method = "Euclidean")
          }
          # Manhattan distance
          if(hclust_distance=="manhattan") {
            w <- proxy::dist(x = x_i, y = x_j, method = "Manhattan")
          }

          # symmetric distances
          stats[[counter]]<-data.frame(c_i = cs[i], c_j = cs[j], B = x, M = mean(w),
                                       n_i = nrow(x_i), n_j = nrow(x_j))
          counter <- counter + 1
          if(i!=j) {
            stats[[counter]]<-data.frame(c_i = cs[j], c_j = cs[i], B = x, M = mean(w),
                                         n_i = nrow(x_j), n_j = nrow(x_i))
            counter <- counter + 1
          }
        }
      }

      stats <- do.call(rbind, stats)
      return(stats)
    }


    # Short description:
    # Compute distance between centroids
    get_c_dist <- function(m, c, hclust_distance) {
      cs <- unique(c)
      stats <- c()
      len_cs <- length(cs)

      stats <- vector(mode = "list", length = len_cs*len_cs)
      counter <- 1
      for(i in seq_len(length.out = len_cs)) {
        x_i <- m[which(c == cs[i]), ]
        x_i <- colMeans(x_i)

        for(j in i:len_cs) {
          x_j <- m[which(c == cs[j]), ]
          x_j <- colMeans(x_j)

          # Euclidean distance
          if(hclust_distance=="euclidean") {
            M <- sqrt(sum((x_i-x_j)^2))
          }
          # Manhattan distance
          if(hclust_distance=="manhattan") {
            M <- sum(abs((x_i-x_j)))
          }

          # symmetric distances
          stats[[counter]] <- data.frame(c_i = cs[i], c_j = cs[j], B = 1, M = M)
          counter <- counter + 1
          if(i!=j) {
            stats[[counter]] <- data.frame(c_i = cs[j], c_j = cs[i], B = 1, M = M)
            counter <- counter + 1
          }
        }
      }

      stats <- do.call(rbind, stats)
      return(stats)
    }


    # Short description:
    # computes summaries (mean + SE) of  inter-cluster PCA distance
    get_p_dist_summary <- function(p_dist) {
      B <- max(p_dist$B)

      m <- merge(x = aggregate(M~c_i+c_j, data = p_dist, FUN = mean),
                 y = aggregate(M~c_i+c_j, data = p_dist, FUN = get_se),
                 by = c("c_i", "c_j"))
      colnames(m) <- c("c_i", "c_j", "M", "SE")
      m$L95 <- m$M-m$SE*1.96
      m$H95 <- m$M+m$SE*1.96

      return(m)
    }


    # Short description:
    # aux. function which computes standard error of num. vector x
    get_se <- function(x) {
      if(missing(x)|length(x)==0) {
        stop("x is missing or length(x)==0")
      }
      if(length(x) == 1) {
        se <- NA
      }
      else {
        se <- sd(x)/sqrt(length(x))
      }
      return(se)
    }


    # get centroid distances
    c_dist <- get_c_dist(m = m, c = c, hclust_distance = hclust_distance)
    p_dist <- NA
    p_dist_summary <- NA

    if(B>0) {
      # get distances between clusters in B bootstrap iterations
      future::plan(future::multisession, workers = cores)
      p_dist <- future.apply::future_lapply(X = seq_len(length.out = B),
                                            FUN = get_p_dist,
                                            m = m,
                                            c = c,
                                            N_eff = N_eff,
                                            hclust_distance = hclust_distance,
                                            future.seed = TRUE)
      future::plan(future::sequential())

      # collect results
      p_dist <- do.call(rbind, p_dist)

      # get additional summaries
      p_dist_summary <- get_p_dist_summary(p_dist = p_dist)
    }

    return(list(c_dist = c_dist,
                p_dist = p_dist,
                p_dist_summary = p_dist_summary))
  }


  get_exact_dist <- function(A, cs) {
    unique_cs <- unique(cs)

    w <- matrix(data = 0, nrow = length(unique_cs), ncol = length(unique_cs))
    colnames(w) <- unique_cs
    rownames(w) <- unique_cs

    for(i in 1:(length(unique_cs)-1)) {
      for(j in (i+1):length(unique_cs)) {
        A_x <- A[which(cs==unique_cs[i]),]
        A_y <- A[which(cs==unique_cs[j]),]

        w[i,j] <- mean(proxy::dist(x = A_x, y = A_y, method = "Euclidean"))
        w[j,i] <- w[i,j]
      }
    }

    w <- reshape2::melt(w)
    colnames(w) <- c("c_i", "c_j", "E")
    w$n_i <- NA
    w$n_j <- NA

    for(i in 1:nrow(w)) {
      w$n_i[i] <- sum(cs == w$c_i[i])
      w$n_j[i] <- sum(cs == w$c_j[i])
    }

    return(w)
  }


  get_delta <- function(e, p, neff, b) {
    w <- merge(x = e, y = p, by = c("c_i", "c_j"))
    w$diff <- w$E-w$M
    w <- w[w$c_i != w$c_j,]
    w$neff <- neff
    w$B <- b

    return(w)
  }

  # compute explicit distances between clusters -> E
  e <- get_exact_dist(A=A, cs=cs)

  neff_res <- vector(mode = "list",
                     length = length(bs)*length(neffs))
  counter <- 1
  for(neff in neffs) {
    for(b in bs) {
      cat("N_eff=", neff, " B=", b, "\n")

      # compute approximate distances as done by scBubbletree -> M
      pd <- get_dist(B = b,
                     m = A,
                     c = cs,
                     N_eff = neff,
                     cores = cores,
                     hclust_distance = "euclidean")

      # compare E and M
      neff_res[[counter]] <- get_delta(e = e,
                                       p = pd$p_dist_summary,
                                       neff = neff,
                                       b = b)
      counter <- counter + 1
    }
  }
  return(do.call(rbind, neff_res))
}

neff <- inspect_neff(A = A, cs = cs, bs = c(100, 200, 400), neffs = c(100, 200, 400), cores = 20)

save(neff, file = "data/CS_B_processed/neff.RData")


neff <- get(load("data/CS_B_processed/neff.RData"))
neff$B_lab <- paste0("B=",neff$B)
neff$B_lab <- factor(x = neff$B_lab, levels = unique(neff$B_lab))
neff$neff_lab <- paste0("Neff=",neff$neff)
neff$neff_lab <- factor(x = neff$neff_lab, levels = unique(neff$neff_lab))

g <- ggplot(data = neff)+
  facet_grid(neff_lab~B_lab)+
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", col = "gray")+
  geom_point(aes(y = M, x = E), size = 0.5)+
  geom_errorbar(aes(y = M, x = E, ymin = L95, ymax = H95), width = 0.1)+
  ggtitle(label = "Dataset B")+
  xlab("Distance computed by bootstrapping")+
  ylab("Distance computed from complete dataset")

ggsave(filename = "data/CS_B_processed/neff.pdf",
       plot = g,
       device = "pdf",
       width = 4,
       height = 4)



##### 4. clustree ######
source("/mnt/nfs/simo/r_utils/Graphics.R")
library(scBubbletree)
library(clustree)


louvain_0_63 <- get(load("data/CS_B_processed/louvain_pc15_r_0.794.RData"))
louvain_0_8 <- get(load("data/CS_B_processed/louvain_pc15_r0.8.RData"))
compare_bubbletrees(btd_1 = louvain_0_8,
                    btd_2 = louvain_0_63,
                    ratio_heatmap = 0.8)
rm(louvain)
louvain$tree
louvain$cluster

q <- merge(x = louvain$pair_dist$c_dist,
           y = louvain$pair_dist$p_dist_summary,
           by = c("c_i", "c_j"))
ggplot(data = q)+
  geom_point(aes(x = M.x, y = M.y))+
  geom_abline(intercept = 0, slope = 1, col = "red")


plot(louvain$ph$main_ph)
plot(louvain$alt_ph$main_ph)

data(nba_clusts)
nba_clusts

clustree(data.frame(K1 = louvain_0_63$cluster,
                    K2 = louvain_0_8$cluster), prefix = "K")




##### 5. Fig 2 ######
source("src/Graphics.R")
library(scBubbletree)
library(patchwork)
library(ggrepel)


d <- get(load("data/CS_B_processed/d.RData"))
meta <- d@meta.data
A <- d@reductions$pca@cell.embeddings[, 1:15]
r15 <- get(load("data/CS_B_processed/data_r_pc15.RData"))
btd <- get(load("data/CS_B_processed/louvain_pc15_r_0.794.RData"))
rm(louvain)


gini_l1 <- get_gini_k(labels = meta$celltype.l1, obj = r15)
gini_l2 <- get_gini_k(labels = meta$celltype.l2, obj = r15)


# panel A
g_gap <- ggplot(r15$gap_stats_summary)+
  geom_line(aes(y = gap_mean, x = k), col = "darkgray")+
  geom_point(aes(y = gap_mean, x = k), size = 0.5, col = "black")+
  geom_errorbar(aes(y = gap_mean, x = k, ymin = L95, ymax = H95), width = 0.1)+
  geom_text_repel(data = r15$gap_stats_summary[r15$gap_stats_summary$k==24, ],
                  aes(x = k, y = gap_mean, label = k), min.segment.length = 0,
                  size = 3, col = "red")+
  geom_text_repel(data = r15$gap_stats_summary[r15$gap_stats_summary$k==15, ],
                  aes(x = k, y = gap_mean, label = k), min.segment.length = 0,
                  size = 3, col = "red")+
  xlab(label = "k'")+
  ylab(label = "Gap")


# panel B
g_wgi <- ggplot()+
  geom_line(data = gini_l1$wgi_summary, aes(x = k, y = wgi), size = 0.2, col = "black")+
  geom_point(data = gini_l1$wgi_summary, aes(x = k, y = wgi), size = 0.5, col = "black")+
  geom_line(data = gini_l2$wgi_summary, aes(x = k, y = wgi), size = 0.2, col = "darkgray")+
  geom_point(data = gini_l2$wgi_summary, aes(x = k, y = wgi), size = 0.5, col = "darkgray")+
  geom_text_repel(data = gini_l2$wgi_summary[gini_l2$wgi_summary$k == 24, ],
                  aes(x = k, y = wgi, label = k), min.segment.length = 0,
                  size = 3, col = "red")+
  geom_text_repel(data = gini_l1$wgi_summary[gini_l1$wgi_summary$k == 24, ],
                  aes(x = k, y = wgi, label = k), min.segment.length = 0,
                  size = 3, col = "red")+
  ylab(label = "WGI")+
  xlab(label = "k'")+
  ylim(c(min(c(gini_l1$wgi_summary$wgi),gini_l2$wgi_summary$wgi)),
       max(c(gini_l1$wgi_summary$wgi, gini_l2$wgi_summary$wgi)))


# panel D
g_l1 <- get_cat_tiles(btd = btd,
                      f = meta[, "celltype.l1"],
                      integrate_vertical = FALSE,
                      round_digits = 1,
                      tile_text_size = 2.75,
                      tile_bw = FALSE,
                      x_axis_name = '',
                      rotate_x_axis_labels = TRUE)


# assemble plots
g_top <- (g_gap|g_gap|g_wgi) + plot_layout(widths = c(0.2, 1, 1))
g_bottom <- (btd$tree|g_l1$plot)+plot_layout(widths = c(1, 1))
g <- g_top/g_bottom + plot_layout(heights = c(1.3, 5))
g <- g + plot_annotation(tag_levels = 'A')

# save
ggsave(plot = g,
       filename = "data/CS_B_processed/fig_2.pdf",
       device = "pdf",
       width = 6.7,
       height = 7.5)








##### 6. Supplementary dataset B ######
source("src/Graphics.R")
library(scBubbletree)
library(patchwork)
library(ggrepel)

d <- get(load("data/CS_B_processed/d.RData"))

meta <- d@meta.data
meta$dt <- paste0(meta$donor, " (", meta$time, ")")

markers_adt <- as.matrix(t(d@assays$ADT@data))
markers_adt <- markers_adt[, c("CD3-1", "CD4-1", "CD8",
                               "CD19", "CD27", "IgM", "IgD",
                               "CD14", "CD16",
                               "CD56-1","CD11c")]

markers_rna <- t(as.matrix(d@assays$SCT@data[
  rownames(d@assays$SCT@data) %in%
    c("IL7R", "CD14", "FCGR3A", "LYZ",
      "MS4A1", "CD8A",
      "GNLY", "NKG7", "MS4A7",
      "FCER1A", "CST3",
      "PPBP",
      "NCAM1", "CD27"), ]))

markers_rna <- markers_rna[,  c("IL7R",
                                "CD14", "FCGR3A", "LYZ",
                                "MS4A1",
                                "CD8A",
                                "GNLY", "NKG7", "MS4A7",
                                "FCER1A", "CST3",
                                "PPBP",
                                "NCAM1", "CD27")]


A <- d@reductions$pca@cell.embeddings[, 1:15]
r15 <- get(load("data/CS_B_processed/data_r_pc15.RData"))
btd <- get(load("data/CS_B_processed/louvain_pc15_r_0.794.RData"))
rm(louvain)

g_l1 <- get_cat_tiles(btd = btd,
                      f = meta[, "celltype.l1"],
                      integrate_vertical = TRUE,
                      round_digits = 0,
                      tile_text_size = 2,
                      tile_bw = FALSE,
                      x_axis_name = '',
                      rotate_x_axis_labels = TRUE)

g_l2 <- get_cat_tiles(btd = btd,
                      f = meta[, "celltype.l2"],
                      integrate_vertical = FALSE,
                      round_digits = 0,
                      tile_text_size = 2,
                      tile_bw = FALSE,
                      x_axis_name = '',
                      rotate_x_axis_labels = TRUE)

g_dt <- get_cat_tiles(btd = btd,
                      f = meta[, "dt"],
                      integrate_vertical = TRUE,
                      round_digits = 0,
                      tile_text_size = 2,
                      tile_bw = FALSE,
                      x_axis_name = '',
                      rotate_x_axis_labels = TRUE)

g_rna <- get_num_tiles(btd = btd,
                       fs = markers_rna,
                       summary_function = "mean",
                       round_digits = 1,
                       rotate_x_axis_labels = T,
                       tile_text_size = 2,
                       x_axis_name = 'RNA',
                       tile_bw = FALSE)

g_adt <- get_num_tiles(btd = btd,
                       fs = markers_adt,
                       summary_function = "mean",
                       round_digits = 1,
                       rotate_x_axis_labels = T,
                       tile_text_size = 2,
                       x_axis_name = 'ADT',
                       tile_bw = FALSE)

g_phase <- get_cat_tiles(btd = btd,
                         f = meta$Phase,
                         integrate_vertical = T,
                         round_digits = 1,
                         tile_text_size = 2,
                         tile_bw = FALSE,
                         x_axis_name = "Cell cycle phase",
                         rotate_x_axis_labels = F)

mt <- meta$mt
names(mt) <- "MT[%]"
rna_count <- meta$nCount_RNA
names(rna_count) <- "RNA count"
gene_count <- meta$nFeature_RNA
names(gene_count) <- "Gene count"

sup_w <- (get_num_violins(btd = btd, fs = mt, rotate_x_axis_labels = F,
                          x_axis_name = "MT [%]")$plot|
            get_num_violins(btd = btd, fs = rna_count/1000, rotate_x_axis_labels = F,
                            x_axis_name = "RNA count (in thousands)")$plot|
            get_num_violins(btd = btd, fs = gene_count, rotate_x_axis_labels = F,
                            x_axis_name = "Gene count")$plot)





g_up <- (btd$tree|g_l1$plot|g_l2$plot|g_dt$plot)+
  plot_layout(widths = c(1, 1, 4, 2.85))


g_down <- (btd$tree|g_rna$plot|g_adt$plot|sup_w|g_phase$plot)+
  plot_layout(widths = c(1, 1.5, 1.5, 4, 0.85))

g <- (g_up/g_down)+plot_annotation(tag_levels = 'A')
g

# save
ggsave(plot = g,
       filename = "data/CS_B_processed/Supplementary_B.pdf",
       device = "pdf",
       width = 15,
       height = 12)
