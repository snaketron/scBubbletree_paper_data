source("src/Graphics.R")
source("src/Stats.R")
require(ggplot2)
require(patchwork)
require(ggforce)


get_bubbledist <- function(n_cells_bubble,
                           labels,
                           pca,
                           umap = NULL,
                           tsne = NULL,
                           treedist = NULL) {


  get_euc <- function(x, y) {
    return(sqrt(apply(X = (x-y)^2, FUN = sum, MARGIN = 1)))
  }

  # labels <- k20$cluster
  u_l <- unique(labels)
  len_ul <- length(u_l)
  l <- vector(mode = "list", length = len_ul*(len_ul-1)/2+len_ul)
  u <- 1

  for(i in 1:len_ul) {
    cat(i, "\n")
    is <- which(labels == u_l[i])
    is <- sample(x = is, size = n_cells_bubble, replace = T)
    for(j in i:len_ul) {
      js <- which(labels == u_l[j])
      js <- sample(x = js, size = n_cells_bubble, replace = T)

      # browser()
      pca_d <- get_euc(x = pca[is,], y = pca[js,])

      umap_d <- NA
      if(is.null(umap)==F) {
        umap_d <- get_euc(x = umap[is,], y = umap[js,])
      }

      tsne_d <- NA
      if(is.null(tsne)==F) {
        tsne_d <- get_euc(x = tsne[is,], y = tsne[js,])
      }

      # browser()
      l[[u]] <- data.frame(
        umap_d = umap_d,
        tsne_d = tsne_d,
        pca_d = pca_d)

      l[[u]]$treedist_d = treedist_data$treedist[which(
        treedist_data$i==u_l[i]&treedist_data$j==u_l[j])]
      l[[u]]$i <- u_l[i]
      l[[u]]$j <- u_l[j]
      l[[u]]$w_vs_b <- ifelse(test = i == j, yes = "w", no = "b")
      u<-u+1
    }
  }

  l <- do.call(rbind, l)
  return (l)
}


get_celldist <- function(n_cells,
                         labels,
                         pca,
                         umap = NULL,
                         tsne = NULL,
                         treedist = NULL) {

  get_euc <- function(x, y) {
    return(sqrt(apply(X = (x-y)^2, FUN = sum, MARGIN = 1)))
  }

  is <- sample(x = 1:nrow(pca), size = n_cells, replace = T)
  js <- sample(x = 1:nrow(pca), size = n_cells, replace = T)

  pca_d <- get_euc(x = pca[is,], y = pca[js,])

  umap_d <- NA
  if(is.null(umap)==F) {
    umap_d <- get_euc(x = umap[is,], y = umap[js,])
  }

  tsne_d <- NA
  if(is.null(tsne)==F) {
    tsne_d <- get_euc(x = tsne[is,], y = tsne[js,])
  }

  l <- data.frame(
    umap_d = umap_d,
    tsne_d = tsne_d,
    pca_d = pca_d)

  l$i <- labels[is]
  l$j <- labels[js]
  l$w_vs_b <- ifelse(test = l$i == l$j, yes = "w", no = "b")

  w <- t(apply(X = l[, c("i", "j")], MARGIN = 1, FUN = sort))
  l$i <- w[, 1]
  l$j <- w[, 2]
  l <- merge(x = l, y = treedist_data, by = c("i", "j"))

  return (l)
}


get_hdi_bins <- function(x,
                         y,
                         xs,
                         x_width) {
  stats <- c()
  for(i in 1:length(xs)) {
    j <- which(x >= (xs[i]-x_width) & x < (xs[i]+x_width))
    hdi <- get_hdi(vec = y[j], hdi_level = 0.95)
    row <- data.frame(x = xs[i],
                      y_mean = mean(y[j]),
                      y_L95 = hdi[1],
                      y_H95 = hdi[2])
    stats <- rbind(stats, row)
  }
  return(stats)
}




k20 <- get(load(file = "data/CS_E/k20_dummy.RData"))
rm(k20_dummy)

treedist_data <- reshape2::melt(ape::cophenetic.phylo(k20$ph$main_ph))
colnames(treedist_data) <- c("i", "j", "tree_d")
rownames(treedist_data) <- paste0(treedist_data$i, '-', treedist_data$j)

tsne <- read.csv(file = "data/CS_E/analysis/tsne/2_components/projection.csv")
colnames(tsne) <- c("B", "tSNE_1", "tSNE_2")

tsne$UMAP_1 <- 1
tsne$UMAP_2 <- 1


# bubbletree
b <- get_bubbledist(n_cells_bubble = 10^4,
                    labels = k20$cluster,
                    pca = k20$A,
                    umap = tsne[, c("UMAP_1", "UMAP_2")],
                    tsne = tsne[, c("tSNE_1", "tSNE_2")],
                    treedist = treedist_data)

b_hdi <- aggregate(pca_d~i+j+w_vs_b, data = b,
                   FUN = get_hdi, hdi_level = 0.95)
b_hdi$pca_L95 <- b_hdi$pca_d[,1]
b_hdi$pca_H95 <- b_hdi$pca_d[,2]
b_hdi$pca_d <- NULL

b_m <- aggregate(pca_d~i+j+w_vs_b, data = b, FUN = mean)
b_m$pca_M <- b_m$pca_d
b_m$pca_d <- NULL

b_stats <- merge(x = b_hdi, y = b_m, by = c("i", "j", "w_vs_b"))
b_stats <- merge(x = b_stats, y = treedist_data, by = c("i", "j"))
rm(b_hdi, b_m)

g_bubbletree <- ggplot(data = b_stats)+
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", col = "darkgray")+
  geom_errorbar(aes(x = tree_d, ymin = pca_L95, ymax = pca_H95, y = pca_M),
                width = 0, size = 0.35, col = "darkgray",
                position = position_jitter(width = 0.5, height = 0, seed = 1234))+
  geom_point(aes(x = tree_d, y = pca_M), size = 0.25,
             position = position_jitter(width = 0.5, height = 0, seed = 1234))+
  xlab(label = "Bubbletree distance")+
  ylab(label = "20D PCA")+
  theme(legend.position = "top")+
  theme_bw(base_size = 10)

g_bubbletree


bin_width <- 2
bin_slide <- 2


# umap + tsne
c <- get_celldist(n_cells = 10^6,
                  labels = k20$cluster,
                  pca = k20$A,
                  umap = tsne[, c("UMAP_1", "UMAP_2")],
                  tsne = tsne[, c("tSNE_1", "tSNE_2")],
                  treedist = treedist_data)

c_tsne_hdi <- get_hdi_bins(x = c$tsne_d,
                           y = c$pca_d,
                           xs = seq(from = 0, to = 65, by = bin_slide),
                           x_width = bin_width)



g_tsne <- ggplot()+
  stat_density_2d(data = c, aes(y = pca_d, x = tsne_d,
                                fill = ..density..),
                  geom = "raster", contour = FALSE) +
  scale_fill_distiller(name = "d", palette= "Spectral", direction=-1)+
  geom_errorbar(data = c_tsne_hdi,
                aes(x = x, ymin = y_L95, ymax = y_H95),
                width = 0, col = "black", size = 0.25)+
  geom_point(data = c_tsne_hdi,
             aes(x = x, y = y_mean), size = 0.25)+
  theme_bw(base_size = 10)+
  theme(legend.position = "none")+
  ylab(label = "20D PCA")+
  xlab(label = "2D t-SNE")+
  scale_x_continuous(expand = c(0.005, 0.005), limits = c(-1, 66))+
  scale_y_continuous(expand = c(0, 0), limits = c(0, 150))
g_tsne


g <- (g_tsne/g_bubbletree)+
  patchwork::plot_annotation(tag_levels = "A")



ggsave(plot = g,
       filename = "data/CS_E/Supplementary_cortex_bubbledist.pdf",
       device = "pdf",
       width = 3.25,
       height = 4)

