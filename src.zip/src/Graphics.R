if(dir.exists("/mnt/nfs/simo/rpack/")) {
  .libPaths(new = "/mnt/nfs/simo/rpack/")
}
require(ggplot2)
ggplot2::theme_set(new = theme_bw(base_size = 10))
