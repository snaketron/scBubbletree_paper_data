source("src/Graphics.R")
source("src/Stats.R")
library(ggplot2)
library(patchwork)
library(Seurat)
dir.create(path = "data/var_explained")


# load Seurat object
d <- get(load(file = "data/CS_A_processed/d.RData"))

var_explained_A <- ((d[["pca"]]@stdev)^2)/d[["pca"]]@misc$total.variance

var_explained_A <- ggplot(data = data.frame(var_explained = var_explained_A*100,
                                            PC = 1:length(var_explained_A)))+
  geom_point(aes(y = var_explained, x = PC), size = 1)+
  ylab(label = "Variance explained [%]")+
  ggtitle("Dataset A")

var_explained_A




d <- get(load("data/CS_B_processed/d.RData"))

var_explained_B <- ((d[["pca"]]@stdev)^2)/d[["pca"]]@misc$total.variance

var_explained_B <- ggplot(data = data.frame(var_explained = var_explained_B*100,
                                            PC = 1:length(var_explained_B)))+
  geom_point(aes(y = var_explained, x = PC), size = 1)+
  ylab(label = "Variance explained [%]")+
  ggtitle("Dataset B")



g <- (var_explained_A|var_explained_B)+plot_annotation(tag_levels = 'A')
ggsave(filename = "data/var_explained/Supplementary_var_explained.pdf",
       plot = g, device = "pdf", width = 6, height = 3)
